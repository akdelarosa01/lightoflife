<?php $__env->startSection('content'); ?>
<div class="container mt-2">
    <div class="row">
        <div class="offset-md-2 col-md-8">
            <div class="card shadow-lg">
                <div class="card-header bg-red text-white">Quiz Grade</div>

                <div class="card-body">

                    <div class="loading"></div>

                    <div class="row mb-2">
                        <div class="col-md-12">
                            <table class="table table-sm table-bordered table-striped" width="100%" id="tbl_quiz">
                                <thead>
                                    <tr>
                                        <td width="5%"></td>
                                        <td>Subject</td>
                                        <td>Section</td>
                                        <td>Title</td>
                                        <td>Quiz Type</td>
                                    </tr>
                                </thead>
                                <tbody id="tbl_quiz_body"></tbody>
                            </table>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('modals.modal_quiz_grade', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('/js/pages/quiz_grade.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>